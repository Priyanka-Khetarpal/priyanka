for (let li of tree.querySelectorAll('li')) {
  let details = document.createElement('details');
  details.open = true;
  li.append(details);
    
  let summary = document.createElement('summary');
  details.prepend(summary);
  summary.append(li.firstChild);
    
  let list = li.querySelector('ul');
  if (list) details.append(list);
}